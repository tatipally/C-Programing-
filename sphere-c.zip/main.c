/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int r;
float radius;
const float PI=3.14;
char line[100];
int main()
{
    printf("Enter the radius of the sphere:");
    fgets(line, sizeof(line), stdin);
    sscanf(line, "%d",&r);
    radius=(4*PI)/(3*3^3);
    printf ("The radius of the sphere is %f", radius);
    return (0);
}

